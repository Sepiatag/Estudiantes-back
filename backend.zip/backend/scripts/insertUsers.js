const bcrypt = require("bcryptjs");
const pool = require("../config/db");

const insertarUsuarios = async () => {
  const usuarios = [
    {
      nombre: "Profesor Juan",
      email: "profe@correo.com",
      password: "profe123",
      rol: "profesor"
    },
    {
      nombre: "Estudiante Ana",
      email: "ana@correo.com",
      password: "ana123",
      rol: "estudiante"
    }
  ];

  for (let user of usuarios) {
    const hashed = await bcrypt.hash(user.password, 10);
    try {
      const res = await pool.query(
        `INSERT INTO usuarios (nombre, email, password, rol, creado_en)
         VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
         RETURNING id, nombre, email, rol`,
        [user.nombre, user.email, hashed, user.rol]
      );
      console.log(`✅ Usuario ${user.rol} insertado:`, res.rows[0]);
    } catch (e) {
      console.error(`❌ Error insertando ${user.rol}:`, e.message);
    }
  }

  pool.end();
};

insertarUsuarios();
