const bcrypt = require("bcryptjs");
const pool = require("../config/db");

const insertarAdmin = async () => {
  const nombre = "Administrador";
  const email = "admin@correo.com";
  const passwordPlano = "admin123";
  const rol = "admin";

  const hashedPassword = await bcrypt.hash(passwordPlano, 10);

  const query = `
    INSERT INTO usuarios (nombre, email, password, rol, creado_en)
    VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
    RETURNING *;
  `;

  try {
    const result = await pool.query(query, [nombre, email, hashedPassword, rol]);
    console.log("✅ Usuario admin insertado:", result.rows[0]);
  } catch (err) {
    console.error("❌ Error al insertar usuario admin:", err.message);
  } finally {
    pool.end();
  }
};

insertarAdmin();
