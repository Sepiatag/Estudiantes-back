const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Conexión BD
require("./config/db");

// Ruta de login y autenticación
const authRoutes = require("./src/routes/auth.routes");
app.use("/auth", authRoutes);
// Ruta para usuarios
const testRoutes = require("./src/routes/test.routes");
app.use("/test", testRoutes);
// Ruta para clases
const claseRoutes = require("./src/routes/clase.routes");
app.use("/clases", claseRoutes);
// Ruta para Deberes
const deberRoutes = require("./src/routes/deber.routes");
app.use("/deberes", deberRoutes);
//Ruta para Entregas
const entregaRoutes = require("./src/routes/entrega.routes");
app.use("/entregas", entregaRoutes);
app.use("/uploads", express.static("uploads"));
// Ruta de Calificaciones
const calificacionRoutes = require("./src/routes/calificacion.routes");
app.use("/calificaciones", calificacionRoutes);
//
const claseEstudiantesRoutes = require("./src/routes/clasesEstudiantes.routes");
app.use("/clases-estudiantes", claseEstudiantesRoutes);



//
app.get("/", (req, res) => {
  res.send("🚀 API Control Estudiantil Activa");
});

app.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});
