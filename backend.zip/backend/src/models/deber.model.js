const pool = require("../../config/db");

const getAllDeberes = async () => {
  const res = await pool.query("SELECT * FROM deberes ORDER BY fecha_entrega ASC");
  return res.rows;
};

const createDeber = async (deber) => {
  const { clase_id, titulo, descripcion, fecha_entrega } = deber;
  const res = await pool.query(
    `INSERT INTO deberes (clase_id, titulo, descripcion, fecha_entrega, creado_en)
     VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP) RETURNING *`,
    [clase_id, titulo, descripcion, fecha_entrega]
  );
  return res.rows[0];
};

const updateDeber = async (id, deber) => {
  const { titulo, descripcion, fecha_entrega } = deber;
  const res = await pool.query(
    `UPDATE deberes
     SET titulo = $1, descripcion = $2, fecha_entrega = $3
     WHERE id = $4 RETURNING *`,
    [titulo, descripcion, fecha_entrega, id]
  );
  return res.rows[0];
};

const deleteDeber = async (id) => {
  const res = await pool.query("DELETE FROM deberes WHERE id = $1 RETURNING *", [id]);
  return res.rows[0];
};

module.exports = {
  getAllDeberes,
  createDeber,
  updateDeber,
  deleteDeber
};
