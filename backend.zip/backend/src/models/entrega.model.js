const pool = require("../../config/db");

const getAllEntregas = async () => {
  const res = await pool.query("SELECT * FROM entregas");
  return res.rows;
};

const getEntregasByEstudiante = async (id) => {
  const res = await pool.query("SELECT * FROM entregas WHERE estudiante_id = $1", [id]);
  return res.rows;
};

const crearEntrega = async ({ deber_id, estudiante_id, archivo_url }) => {
  const res = await pool.query(
    `INSERT INTO entregas (deber_id, estudiante_id, archivo_url, estado, fecha_entrega)
     VALUES ($1, $2, $3, 'entregado', CURRENT_TIMESTAMP)
     RETURNING *`,
    [deber_id, estudiante_id, archivo_url]
  );
  return res.rows[0];
};

const actualizarEntrega = async (id, { estado, calificacion }) => {
  const res = await pool.query(
    `UPDATE entregas SET estado = $1, calificacion = $2 WHERE id = $3 RETURNING *`,
    [estado, calificacion, id]
  );
  return res.rows[0];
};

module.exports = {
  getAllEntregas,
  getEntregasByEstudiante,
  crearEntrega,
  actualizarEntrega
};
