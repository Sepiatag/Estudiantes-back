const pool = require("../../config/db");

const getAll = async () => {
  const res = await pool.query("SELECT * FROM calificaciones");
  return res.rows;
};

const getByEstudiante = async (id) => {
  const res = await pool.query("SELECT * FROM calificaciones WHERE estudiante_id = $1", [id]);
  return res.rows;
};

const crear = async ({ estudiante_id, clase_id, promedio, observaciones }) => {
  const res = await pool.query(
    `INSERT INTO calificaciones (estudiante_id, clase_id, promedio, observaciones)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [estudiante_id, clase_id, promedio, observaciones]
  );
  return res.rows[0];
};

const actualizar = async (id, { promedio, observaciones }) => {
  const res = await pool.query(
    `UPDATE calificaciones SET promedio = $1, observaciones = $2 WHERE id = $3 RETURNING *`,
    [promedio, observaciones, id]
  );
  return res.rows[0];
};

const eliminar = async (id) => {
  const res = await pool.query("DELETE FROM calificaciones WHERE id = $1 RETURNING *", [id]);
  return res.rows[0];
};

module.exports = {
  getAll,
  getByEstudiante,
  crear,
  actualizar,
  eliminar
};
