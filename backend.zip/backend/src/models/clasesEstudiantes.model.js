const pool = require("../../config/db");

const ClasesEstudiantes = {
  getAll: async () => {
    const result = await pool.query("SELECT * FROM clases_estudiantes");
    return result.rows;
  },

  crear: async (clase_id, estudiante_id) => {
    const result = await pool.query(
      "INSERT INTO clases_estudiantes (clase_id, estudiante_id) VALUES ($1, $2) RETURNING *",
      [clase_id, estudiante_id]
    );
    return result.rows[0];
  },

  eliminar: async (id) => {
    const result = await pool.query(
      "DELETE FROM clases_estudiantes WHERE id = $1 RETURNING *",
      [id]
    );
    return result.rows[0];
  },

  getMisClases: async (estudiante_id) => {
    const result = await pool.query(
      `SELECT c.* FROM clases c
       INNER JOIN clases_estudiantes ce ON ce.clase_id = c.id
       WHERE ce.estudiante_id = $1`,
      [estudiante_id]
    );
    return result.rows;
  },
};

module.exports = ClasesEstudiantes;
