const pool = require("../../config/db");

const getAllClases = async () => {
  const result = await pool.query("SELECT * FROM clases");
  return result.rows;
};

const createClase = async ({ nombre, descripcion, profesor_id, periodo_id }) => {
  const result = await pool.query(
    `INSERT INTO clases (nombre, descripcion, profesor_id, periodo_id, creado_en)
     VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
     RETURNING *`,
    [nombre, descripcion, profesor_id, periodo_id]
  );
  return result.rows[0];
};

const updateClase = async (id, data) => {
  const result = await pool.query(
    `UPDATE clases
     SET nombre = $1, descripcion = $2, profesor_id = $3, periodo_id = $4
     WHERE id = $5 RETURNING *`,
    [data.nombre, data.descripcion, data.profesor_id, data.periodo_id, id]
  );
  return result.rows[0];
};

const deleteClase = async (id) => {
  const result = await pool.query("DELETE FROM clases WHERE id = $1 RETURNING *", [id]);
  return result.rows[0];
};

module.exports = {
  getAllClases,
  createClase,
  updateClase,
  deleteClase
};
