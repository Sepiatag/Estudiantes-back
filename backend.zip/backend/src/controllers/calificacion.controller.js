const Calificacion = require("../models/calificacion.model");

const getAll = async (req, res) => {
  try {
    const data = await Calificacion.getAll();
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener calificaciones" });
  }
};

const getMias = async (req, res) => {
  try {
    const data = await Calificacion.getByEstudiante(req.user.id);
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener tus calificaciones" });
  }
};

const crear = async (req, res) => {
  try {
    const nueva = await Calificacion.crear(req.body);
    res.status(201).json(nueva);
  } catch (err) {
    res.status(500).json({ message: "Error al registrar calificación" });
  }
};

const actualizar = async (req, res) => {
  try {
    const actualizada = await Calificacion.actualizar(req.params.id, req.body);
    res.json(actualizada);
  } catch (err) {
    res.status(500).json({ message: "Error al actualizar calificación" });
  }
};

const eliminar = async (req, res) => {
  try {
    const eliminada = await Calificacion.eliminar(req.params.id);
    res.json(eliminada);
  } catch (err) {
    res.status(500).json({ message: "Error al eliminar calificación" });
  }
};

module.exports = { getAll, getMias, crear, actualizar, eliminar };
