const Clase = require("../models/clase.model");

const getClases = async (req, res) => {
  try {
    const clases = await Clase.getAllClases();
    res.json(clases);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener clases" });
  }
};

const createClase = async (req, res) => {
  try {
    const nueva = await Clase.createClase(req.body);
    res.status(201).json(nueva);
  } catch (err) {
    res.status(500).json({ message: "Error al crear clase" });
  }
};

const updateClase = async (req, res) => {
  try {
    const actualizada = await Clase.updateClase(req.params.id, req.body);
    res.json(actualizada);
  } catch (err) {
    res.status(500).json({ message: "Error al actualizar clase" });
  }
};

const deleteClase = async (req, res) => {
  try {
    const eliminada = await Clase.deleteClase(req.params.id);
    res.json(eliminada);
  } catch (err) {
    res.status(500).json({ message: "Error al eliminar clase" });
  }
};

module.exports = {
  getClases,
  createClase,
  updateClase,
  deleteClase
};
