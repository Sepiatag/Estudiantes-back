const ClasesEstudiantes = require("../models/clasesEstudiantes.model");

exports.getAll = async (req, res) => {
  const data = await ClasesEstudiantes.getAll();
  res.json(data);
};

exports.crear = async (req, res) => {
  const { clase_id, estudiante_id } = req.body;
  const nueva = await ClasesEstudiantes.crear(clase_id, estudiante_id);
  res.status(201).json(nueva);
};

exports.eliminar = async (req, res) => {
  const { id } = req.params;
  const eliminado = await ClasesEstudiantes.eliminar(id);
  res.json(eliminado);
};

exports.getMisClases = async (req, res) => {
  const estudiante_id = req.user.id;
  const clases = await ClasesEstudiantes.getMisClases(estudiante_id);
  res.json(clases);
};
