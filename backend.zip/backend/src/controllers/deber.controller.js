const Deber = require("../models/deber.model");

const getDeberes = async (req, res) => {
  try {
    const deberes = await Deber.getAllDeberes();
    res.json(deberes);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener deberes" });
  }
};

const createDeber = async (req, res) => {
  try {
    const nuevo = await Deber.createDeber(req.body);
    res.status(201).json(nuevo);
  } catch (err) {
    res.status(500).json({ message: "Error al crear deber" });
  }
};

const updateDeber = async (req, res) => {
  try {
    const actualizado = await Deber.updateDeber(req.params.id, req.body);
    res.json(actualizado);
  } catch (err) {
    res.status(500).json({ message: "Error al actualizar deber" });
  }
};

const deleteDeber = async (req, res) => {
  try {
    const eliminado = await Deber.deleteDeber(req.params.id);
    res.json(eliminado);
  } catch (err) {
    res.status(500).json({ message: "Error al eliminar deber" });
  }
};

module.exports = {
  getDeberes,
  createDeber,
  updateDeber,
  deleteDeber
};
