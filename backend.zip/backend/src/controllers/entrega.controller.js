const Entrega = require("../models/entrega.model");

const getAll = async (req, res) => {
  try {
    const data = await Entrega.getAllEntregas();
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener entregas" });
  }
};

const getMias = async (req, res) => {
  try {
    const data = await Entrega.getEntregasByEstudiante(req.user.id);
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener tus entregas" });
  }
};

const subir = async (req, res) => {
  try {
    const archivo = req.file?.filename;
    const { deber_id } = req.body;
    const nueva = await Entrega.crearEntrega({
      deber_id,
      estudiante_id: req.user.id,
      archivo_url: archivo
    });
    res.status(201).json(nueva);
  } catch (err) {
    res.status(500).json({ message: "Error al subir entrega" });
  }
};

const actualizar = async (req, res) => {
  try {
    const actualizado = await Entrega.actualizarEntrega(req.params.id, req.body);
    res.json(actualizado);
  } catch (err) {
    res.status(500).json({ message: "Error al actualizar entrega" });
  }
};

module.exports = { getAll, getMias, subir, actualizar };
