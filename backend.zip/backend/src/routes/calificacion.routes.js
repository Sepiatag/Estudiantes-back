const express = require("express");
const router = express.Router();
const {
  getAll,
  getMias,
  crear,
  actualizar,
  eliminar
} = require("../controllers/calificacion.controller");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");

router.get("/", verifyToken, allowRoles("admin", "profesor"), getAll);
router.get("/mias", verifyToken, allowRoles("estudiante"), getMias);
router.post("/", verifyToken, allowRoles("profesor"), crear);
router.put("/:id", verifyToken, allowRoles("profesor"), actualizar);
router.delete("/:id", verifyToken, allowRoles("admin"), eliminar);

module.exports = router;
