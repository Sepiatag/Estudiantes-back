const express = require("express");
const router = express.Router();
const { getClases, createClase, updateClase, deleteClase } = require("../controllers/clase.controller");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");

router.get("/", verifyToken, getClases);
router.post("/", verifyToken, allowRoles("admin", "profesor"), createClase);
router.put("/:id", verifyToken, allowRoles("admin", "profesor"), updateClase);
router.delete("/:id", verifyToken, allowRoles("admin"), deleteClase);

module.exports = router;
