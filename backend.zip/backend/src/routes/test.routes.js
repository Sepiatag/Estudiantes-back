const express = require("express");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");

const router = express.Router();

router.get("/privada", verifyToken, (req, res) => {
  res.json({ message: `Bienvenido ${req.user.rol}`, user: req.user });
});

router.get("/solo-admin", verifyToken, allowRoles("admin"), (req, res) => {
  res.json({ message: "Solo admin puede ver esto" });
});

router.get("/solo-profesor", verifyToken, allowRoles("profesor"), (req, res) => {
  res.json({ message: "Solo profesores pueden ver esto" });
});

module.exports = router;
