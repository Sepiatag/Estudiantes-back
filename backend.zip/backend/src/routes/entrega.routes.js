const express = require("express");
const router = express.Router();
const { getAll, getMias, subir, actualizar } = require("../controllers/entrega.controller");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");
const upload = require("../middlewares/upload.middleware");

router.get("/", verifyToken, allowRoles("admin", "profesor"), getAll);
router.get("/mias", verifyToken, allowRoles("estudiante"), getMias);
router.post("/", verifyToken, allowRoles("estudiante"), upload.single("archivo"), subir);
router.put("/:id", verifyToken, allowRoles("profesor", "estudiante"), actualizar);

module.exports = router;
