const express = require("express");
const router = express.Router();
const {
  getAll,
  crear,
  eliminar,
  getMisClases,
} = require("../controllers/clasesEstudiantes.controller");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");

router.get("/", verifyToken, allowRoles("admin", "profesor"), getAll);
router.post("/", verifyToken, allowRoles("admin", "profesor"), crear);
router.delete("/:id", verifyToken, allowRoles("admin", "profesor"), eliminar);
router.get("/mis-clases", verifyToken, allowRoles("estudiante"), getMisClases);

module.exports = router;
