const express = require("express");
const router = express.Router();
const { getDeberes, createDeber, updateDeber, deleteDeber } = require("../controllers/deber.controller");
const { verifyToken, allowRoles } = require("../middlewares/verifyToken");

router.get("/", verifyToken, getDeberes);
router.post("/", verifyToken, allowRoles("profesor"), createDeber);
router.put("/:id", verifyToken, allowRoles("profesor"), updateDeber);
router.delete("/:id", verifyToken, allowRoles("profesor", "admin"), deleteDeber);

module.exports = router;
