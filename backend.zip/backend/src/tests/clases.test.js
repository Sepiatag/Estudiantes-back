const request = require("supertest");
const express = require("express");
const claseRoutes = require("../routes/clase.routes");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use("/clases", claseRoutes);

const tokenAdmin = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sIjoiYWRtaW4iLCJpYXQiOjE3NTM1NDgwMTYsImV4cCI6MTc1MzU1MTYxNn0.fdYMQdJ6B8RboGE1LB8VTnIwjUhuNGJkDC7AZNffaQs";
const tokenProfe = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwicm9sIjoicHJvZmVzb3IiLCJpYXQiOjE3NTM1NDc5NzQsImV4cCI6MTc1MzU1MTU3NH0.fi3GwVuJ-L6h4jAbpZuVFU3Cs_nR7VNvPfN7Jm2w0uc";
const tokenEstudiante = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Mywicm9sIjoiZXN0dWRpYW50ZSIsImlhdCI6MTc1MzU0NzkyNiwiZXhwIjoxNzUzNTUxNTI2fQ.Xzt77NOB7DmsHbIHPZDDwOKRrF0An7rmp-Jp0xolNGk";
const fakeToken = "Bearer eyJhbGciOiJIUzI1NiIsInR...invalido";

describe("🔍 Pruebas para /clases", () => {

  test("❌ GET sin token → 401", async () => {
    const res = await request(app).get("/clases");
    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe("Token requerido");
  });

  test("✅ GET con token válido → 200", async () => {
    const res = await request(app)
      .get("/clases")
      .set("Authorization", `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("❌ POST con estudiante → 403", async () => {
    const res = await request(app)
      .post("/clases")
      .set("Authorization", tokenEstudiante)
      .send({
        nombre: "Prueba Estudiante",
        descripcion: "No debería poder crear",
        profesor_id: 2,
        periodo_id: 1
      });

    expect(res.statusCode).toBe(403);
    expect(res.body.message).toBe("Acceso no autorizado");
  });

  test("❌ POST con token inválido → 401", async () => {
    const res = await request(app)
      .post("/clases")
      .set("Authorization", fakeToken)
      .send({
        nombre: "Clase falsa",
        descripcion: "Debería fallar",
        profesor_id: 2,
        periodo_id: 1
      });

    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe("Token inválido o expirado");
  });

  test("✅ POST clase con token admin → 201", async () => {
    const res = await request(app)
      .post("/clases")
      .set("Authorization", `Bearer ${tokenAdmin}`)
      .send({
        nombre: "Historia Universal",
        descripcion: "Desde Mesopotamia hasta la actualidad",
        profesor_id: 2,
        periodo_id: 1
      });

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty("id");
    expect(res.body.nombre).toBe("Historia Universal");
  });
});
