const request = require("supertest");
const express = require("express");
const entregaRoutes = require("../routes/entrega.routes");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use("/entregas", entregaRoutes);

// Tokens
const tokenEstudiante = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Mywicm9sIjoiZXN0dWRpYW50ZSIsImlhdCI6MTc1MzU0NzkyNiwiZXhwIjoxNzUzNTUxNTI2fQ.Xzt77NOB7DmsHbIHPZDDwOKRrF0An7rmp-Jp0xolNGk";
const tokenProfesor = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwicm9sIjoicHJvZmVzb3IiLCJpYXQiOjE3NTM1NDc5NzQsImV4cCI6MTc1MzU1MTU3NH0.fi3GwVuJ-L6h4jAbpZuVFU3Cs_nR7VNvPfN7Jm2w0uc";
const tokenAdmin = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sIjoiYWRtaW4iLCJpYXQiOjE3NTM1NDgwMTYsImV4cCI6MTc1MzU1MTYxNn0.fdYMQdJ6B8RboGE1LB8VTnIwjUhuNGJkDC7AZNffaQs";

describe("📂 Pruebas para /entregas", () => {
  let entregaId = null;

  test("❌ GET /entregas sin token → 401", async () => {
    const res = await request(app).get("/entregas");
    expect(res.statusCode).toBe(401);
  });

  test("✅ GET /entregas con token profesor → 200", async () => {
    const res = await request(app)
      .get("/entregas")
      .set("Authorization", `Bearer ${tokenProfesor}`)

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("✅ GET /entregas/mias con estudiante → 200", async () => {
    const res = await request(app)
      .get("/entregas/mias")
      .set("Authorization", tokenEstudiante);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("✅ POST /entregas (subida falsa) → 201", async () => {
    const res = await request(app)
      .post("/entregas")
      .set("Authorization", tokenEstudiante)
      .field("deber_id", 1)
      .attach("archivo", Buffer.from("Archivo de prueba"), "prueba.txt");

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty("id");
    entregaId = res.body.id;
  });

  test("✅ PUT /entregas/:id califica profesor → 200", async () => {
    const res = await request(app)
      .put(`/entregas/${entregaId}`)
      .set("Authorization", `Bearer ${tokenProfesor}`)
      .send({
        estado: "calificado",
        calificacion: 90
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.calificacion).toBe(90);
  });
});
