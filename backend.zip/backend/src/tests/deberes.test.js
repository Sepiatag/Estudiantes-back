const request = require("supertest");
const express = require("express");
const deberRoutes = require("../routes/deber.routes");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use("/deberes", deberRoutes);

// Tokens
const tokenProfesor = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwicm9sIjoicHJvZmVzb3IiLCJpYXQiOjE3NTM1NDc5NzQsImV4cCI6MTc1MzU1MTU3NH0.fi3GwVuJ-L6h4jAbpZuVFU3Cs_nR7VNvPfN7Jm2w0uc";
const tokenEstudiante = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Mywicm9sIjoiZXN0dWRpYW50ZSIsImlhdCI6MTc1MzU0NzkyNiwiZXhwIjoxNzUzNTUxNTI2fQ.Xzt77NOB7DmsHbIHPZDDwOKRrF0An7rmp-Jp0xolNGk";
const tokenAdmin = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sIjoiYWRtaW4iLCJpYXQiOjE3NTM1NDgwMTYsImV4cCI6MTc1MzU1MTYxNn0.fdYMQdJ6B8RboGE1LB8VTnIwjUhuNGJkDC7AZNffaQs";

describe("📘 Pruebas para /deberes", () => {
  let deberCreadoId = null;

  test("❌ GET sin token → 401", async () => {
    const res = await request(app).get("/deberes");
    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe("Token requerido");
  });

  test("✅ GET con token profesor → 200", async () => {
    const res = await request(app)
      .get("/deberes")
      .set("Authorization", `Bearer ${tokenProfesor}`)


    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("❌ POST con estudiante → 403", async () => {
    const res = await request(app)
      .post("/deberes")
      .set("Authorization", tokenEstudiante)
      .send({
        clase_id: 2,
        titulo: "No permitido",
        descripcion: "El estudiante no debe poder",
        fecha_entrega: "2025-08-31"
      });

    expect(res.statusCode).toBe(403);
    expect(res.body.message).toBe("Acceso no autorizado");
  });

  test("✅ POST con profesor → 201", async () => {
    const res = await request(app)
      .post("/deberes")
      .set("Authorization", `Bearer ${tokenProfesor}`)
      .send({
        clase_id: 2,
        titulo: "Test de tarea",
        descripcion: "Descripción test",
        fecha_entrega: "2025-08-31"
      });

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty("id");
    deberCreadoId = res.body.id;
  });

  test("✅ PUT deber con profesor → 200", async () => {
    const res = await request(app)
      .put(`/deberes/${deberCreadoId}`)
      .set("Authorization", `Bearer ${tokenProfesor}`)
      .send({
        titulo: "Actualizado por test",
        descripcion: "Cambio hecho por test",
        fecha_entrega: "2025-09-10"
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.titulo).toBe("Actualizado por test");
  });

  test("✅ DELETE con admin → 200", async () => {
    const res = await request(app)
      .delete(`/deberes/${deberCreadoId}`)
      .set("Authorization", `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.id).toBe(deberCreadoId);
  });
});
