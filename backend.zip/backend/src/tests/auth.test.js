const request = require("supertest");
const express = require("express");
require("dotenv").config();
const authRoutes = require("../routes/auth.routes");
const app = express();

app.use(express.json());
app.use("/auth", authRoutes);

describe("Pruebas de /auth/login", () => {
  test("✅ Login exitoso", async () => {
    const res = await request(app)
      .post("/auth/login")
      .send({
        email: "admin@correo.com",
        password: "admin123"
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty("token");
    expect(res.body.user.email).toBe("admin@correo.com");
  });

  test("❌ Usuario no encontrado", async () => {
    const res = await request(app)
      .post("/auth/login")
      .send({
        email: "inexistente@correo.com",
        password: "admin123"
      });

    expect(res.statusCode).toBe(404);
    expect(res.body.message).toBe("Usuario no encontrado");
  });

  test("❌ Contraseña incorrecta", async () => {
    const res = await request(app)
      .post("/auth/login")
      .send({
        email: "admin@correo.com",
        password: "malacontra"
      });

    expect(res.statusCode).toBe(401);
    expect(res.body.message).toBe("Contraseña incorrecta");
  });
});
