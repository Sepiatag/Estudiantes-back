const request = require("supertest");
const express = require("express");
const calificacionRoutes = require("../routes/calificacion.routes");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use("/calificaciones", calificacionRoutes);

// Tokens
const tokenAdmin = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwicm9sIjoiYWRtaW4iLCJpYXQiOjE3NTM1NDgwMTYsImV4cCI6MTc1MzU1MTYxNn0.fdYMQdJ6B8RboGE1LB8VTnIwjUhuNGJkDC7AZNffaQs";
const tokenProfesor = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Miwicm9sIjoicHJvZmVzb3IiLCJpYXQiOjE3NTM1NDc5NzQsImV4cCI6MTc1MzU1MTU3NH0.fi3GwVuJ-L6h4jAbpZuVFU3Cs_nR7VNvPfN7Jm2w0uc";
const tokenEstudiante = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6Mywicm9sIjoiZXN0dWRpYW50ZSIsImlhdCI6MTc1MzU0NzkyNiwiZXhwIjoxNzUzNTUxNTI2fQ.Xzt77NOB7DmsHbIHPZDDwOKRrF0An7rmp-Jp0xolNGk";

describe("🎓 Pruebas para /calificaciones", () => {
  let califId = null;

  test("✅ GET /calificaciones como profesor", async () => {
    const res = await request(app)
      .get("/calificaciones")
      .set("Authorization", `Bearer ${tokenProfesor}`)


    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("✅ GET /calificaciones/mias como estudiante", async () => {
    const res = await request(app)
      .get("/calificaciones/mias")
      .set("Authorization", tokenEstudiante);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test("✅ POST /calificaciones como profesor", async () => {
    const res = await request(app)
      .post("/calificaciones")
      .set("Authorization", `Bearer ${tokenProfesor}`)
      .send({
        estudiante_id: 3,
        clase_id: 2,
        promedio: 84,
        observaciones: "Buen rendimiento en general"
      });

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty("id");
    califId = res.body.id;
  });

  test("✅ PUT /calificaciones/:id como profesor", async () => {
    const res = await request(app)
      .put(`/calificaciones/${califId}`)
      .set("Authorization", `Bearer ${tokenProfesor}`)
      .send({
        promedio: 90,
        observaciones: "Actualizado por revisión final"
      });

    expect(res.statusCode).toBe(200);
    expect(Number(res.body.promedio)).toBe(90);

  });

  test("✅ DELETE /calificaciones/:id como admin", async () => {
    const res = await request(app)
      .delete(`/calificaciones/${califId}`)
      .set("Authorization", `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.id).toBe(califId);
  });
});
